package com.example.iledupeintre

import android.content.Context
import android.graphics.*
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.SurfaceHolder
import android.view.SurfaceView
import kotlin.math.sqrt

class GameView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null
) : SurfaceView(context, attrs), SurfaceHolder.Callback, Runnable {

    private var thread: Thread? = null
    private var isPlaying = false

    private var screenWidth = 0f
    private var screenHeight = 0f
    private var gameAreaRect = RectF()

    private var currentLevel = 1
    private val maxLevels = 6
    private var playerHearts = 5
    private var keysCollected = 0
    private var totalKeysInLevel = 2

    private var playerX = 0f
    private var playerY = 0f
    private var playerRadius = 40f
    private var playerSpeed = 12f
    private var isAttacking = false
    private var attackTimer = 0

    private var dpadUp = RectF()
    private var dpadDown = RectF()
    private var dpadLeft = RectF()
    private var dpadRight = RectF()
    private var paintButton = RectF()

    private var moveUp = false
    private var moveDown = false
    private var moveLeft = false
    private var moveRight = false

    private val enemies = mutableListOf<Enemy>()
    private val keys = mutableListOf<PointF>()
    private val paintSplatters = mutableListOf<PaintSplatter>()

    private val bgPaint = Paint().apply { color = Color.parseColor("#3e7d32") }
    private val textPaint = Paint().apply {
        color = Color.WHITE
        textSize = 42f
        typeface = Typeface.DEFAULT_BOLD
    }
    private val btnPaint = Paint().apply { color = Color.parseColor("#34344e") }
    private val actionBtnPaint = Paint().apply { color = Color.parseColor("#e63946") }

    init {
        holder.addCallback(this)
    }

    override fun surfaceCreated(holder: SurfaceHolder) {
        screenWidth = width.toFloat()
        screenHeight = height.toFloat()

        val gameHeight = screenWidth * 1.1f
        gameAreaRect.set(20f, 120f, screenWidth - 20f, 120f + gameHeight)

        setupControls()
        loadLevel(currentLevel)

        isPlaying = true
        thread = Thread(this)
        thread?.start()
    }

    private fun setupControls() {
        val dpadSize = 120f
        val dpadCenterX = 200f
        val dpadCenterY = screenHeight - 220f

        dpadUp.set(dpadCenterX - dpadSize / 2, dpadCenterY - dpadSize * 1.5f, dpadCenterX + dpadSize / 2, dpadCenterY - dpadSize / 2)
        dpadDown.set(dpadCenterX - dpadSize / 2, dpadCenterY + dpadSize / 2, dpadCenterX + dpadSize / 2, dpadCenterY + dpadSize * 1.5f)
        dpadLeft.set(dpadCenterX - dpadSize * 1.5f, dpadCenterY - dpadSize / 2, dpadCenterX - dpadSize / 2, dpadCenterY + dpadSize / 2)
        dpadRight.set(dpadCenterX + dpadSize / 2, dpadCenterY - dpadSize / 2, dpadCenterX + dpadSize * 1.5f, dpadCenterY + dpadSize / 2)

        val btnRadius = 130f
        val btnX = screenWidth - 200f
        val btnY = screenHeight - 220f
        paintButton.set(btnX - btnRadius, btnY - btnRadius, btnX + btnRadius, btnY + btnRadius)
    }

    private fun loadLevel(level: Int) {
        playerX = gameAreaRect.centerX()
        playerY = gameAreaRect.bottom - 100f
        keysCollected = 0
        enemies.clear()
        keys.clear()
        paintSplatters.clear()

        keys.add(PointF(gameAreaRect.left + 100f, gameAreaRect.top + 150f))
        keys.add(PointF(gameAreaRect.right - 100f, gameAreaRect.top + 150f))

        when (level) {
            1 -> enemies.add(Enemy("Trump", gameAreaRect.centerX(), gameAreaRect.top + 250f, Color.parseColor("#d62828")))
            2 -> {
                enemies.add(Enemy("Putin", gameAreaRect.left + 150f, gameAreaRect.top + 250f, Color.parseColor("#003049")))
                enemies.add(Enemy("Trump", gameAreaRect.right - 150f, gameAreaRect.top + 250f, Color.parseColor("#d62828")))
            }
            3 -> enemies.add(Enemy("Melania", gameAreaRect.centerX(), gameAreaRect.top + 300f, Color.parseColor("#9d4edd"), speed = 7f))
            4 -> {
                enemies.add(Enemy("Xi", gameAreaRect.left + 200f, gameAreaRect.top + 200f, Color.parseColor("#f77f00")))
                enemies.add(Enemy("Putin", gameAreaRect.right - 200f, gameAreaRect.top + 200f, Color.parseColor("#003049")))
            }
            5 -> enemies.add(Enemy("Kim", gameAreaRect.centerX(), gameAreaRect.top + 200f, Color.parseColor("#2b2d42"), health = 5))
            6 -> {
                enemies.add(Enemy("Trump", gameAreaRect.left + 120f, gameAreaRect.top + 200f, Color.parseColor("#d62828"), health = 3))
                enemies.add(Enemy("Putin", gameAreaRect.centerX(), gameAreaRect.top + 200f, Color.parseColor("#003049"), health = 3))
                enemies.add(Enemy("Kim", gameAreaRect.right - 120f, gameAreaRect.top + 200f, Color.parseColor("#2b2d42"), health = 4))
            }
        }
    }

    override fun run() {
        while (isPlaying) {
            update()
            draw()
            try {
                Thread.sleep(16)
            } catch (e: InterruptedException) {
                e.printStackTrace()
            }
        }
    }

    private fun update() {
        if (moveUp && playerY - playerSpeed > gameAreaRect.top + playerRadius) playerY -= playerSpeed
        if (moveDown && playerY + playerSpeed < gameAreaRect.bottom - playerRadius) playerY += playerSpeed
        if (moveLeft && playerX - playerSpeed > gameAreaRect.left + playerRadius) playerX -= playerSpeed
        if (moveRight && playerX + playerSpeed < gameAreaRect.right - playerRadius) playerX += playerSpeed

        if (isAttacking) {
            attackTimer++
            if (attackTimer > 12) {
                isAttacking = false
                attackTimer = 0
            }
        }

        val keyIterator = keys.iterator()
        while (keyIterator.hasNext()) {
            val key = keyIterator.next()
            val dist = sqrt((playerX - key.x) * (playerX - key.x) + (playerY - key.y) * (playerY - key.y))
            if (dist < 60f) {
                keysCollected++
                keyIterator.remove()
            }
        }

        for (enemy in enemies) {
            if (!enemy.isDead) {
                enemy.update(playerX, playerY, gameAreaRect)

                val dist = sqrt((playerX - enemy.x) * (playerX - enemy.x) + (playerY - enemy.y) * (playerY - enemy.y))
                if (dist < playerRadius + enemy.radius) {
                    if (isAttacking) {
                        enemy.health--
                        paintSplatters.add(PaintSplatter(enemy.x, enemy.y, enemy.color))
                        if (enemy.health <= 0) enemy.isDead = true
                        isAttacking = false
                    } else if (enemy.canAttackPlayer()) {
                        playerHearts--
                        if (playerHearts <= 0) {
                            playerHearts = 5
                            loadLevel(currentLevel)
                        }
                    }
                }
            }
        }

        if (keysCollected >= totalKeysInLevel && enemies.all { it.isDead }) {
            if (currentLevel < maxLevels) {
                currentLevel++
                loadLevel(currentLevel)
            }
        }
    }

    private fun draw() {
        if (holder.surface.isValid) {
            val canvas = holder.lockCanvas()
            canvas.drawColor(Color.parseColor("#121218"))

            canvas.drawRect(gameAreaRect, bgPaint)

            for (splatter in paintSplatters) {
                val p = Paint().apply { color = splatter.color; alpha = 180 }
                canvas.drawCircle(splatter.x, splatter.y, splatter.radius, p)
            }

            val keyPaint = Paint().apply { color = Color.YELLOW }
            for (key in keys) {
                canvas.drawCircle(key.x, key.y, 20f, keyPaint)
            }

            for (enemy in enemies) {
                if (!enemy.isDead) {
                    enemy.draw(canvas)
                }
            }

            drawHero(canvas, playerX, playerY)

            if (isAttacking) {
                val brushPaint = Paint().apply {
                    color = Color.CYAN
                    strokeWidth = 14f
                    style = Paint.Style.STROKE
                }
                canvas.drawCircle(playerX, playerY, playerRadius + 40f, brushPaint)
            }

            val heartPaint = Paint().apply { color = Color.RED }
            for (i in 0 until playerHearts) {
                canvas.drawCircle(60f + i * 45f, 60f, 16f, heartPaint)
            }
            canvas.drawText("Clés: $keysCollected/$totalKeysInLevel | Nivel $currentLevel/$maxLevels", screenWidth - 520f, 75f, textPaint)

            canvas.drawRoundRect(dpadUp, 20f, 20f, btnPaint)
            canvas.drawRoundRect(dpadDown, 20f, 20f, btnPaint)
            canvas.drawRoundRect(dpadLeft, 20f, 20f, btnPaint)
            canvas.drawRoundRect(dpadRight, 20f, 20f, btnPaint)

            canvas.drawOval(paintButton, actionBtnPaint)
            canvas.drawText("Peindre", paintButton.centerX() - 65f, paintButton.centerY() + 15f, textPaint)

            holder.unlockCanvasAndPost(canvas)
        }
    }

    private fun drawHero(canvas: Canvas, x: Float, y: Float) {
        val p = Paint()
        p.color = Color.parseColor("#1d3557")
        canvas.drawRect(x - 20f, y - 10f, x + 20f, y + 35f, p)

        p.color = Color.parseColor("#f1faee")
        canvas.drawCircle(x, y - 30f, 22f, p)

        p.color = Color.parseColor("#d4a373")
        canvas.drawCircle(x - 25f, y, 8f, p)
        canvas.drawCircle(x + 25f, y, 8f, p)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        val x = event.x
        val y = event.y

        when (event.action and MotionEvent.ACTION_MASK) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                if (dpadUp.contains(x, y)) moveUp = true
                if (dpadDown.contains(x, y)) moveDown = true
                if (dpadLeft.contains(x, y)) moveLeft = true
                if (dpadRight.contains(x, y)) moveRight = true

                if (paintButton.contains(x, y)) {
                    isAttacking = true
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP -> {
                moveUp = false
                moveDown = false
                moveLeft = false
                moveRight = false
            }
        }
        return true
    }

    override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {}
    override fun surfaceDestroyed(holder: SurfaceHolder) {
        isPlaying = false
        thread?.join()
    }
}

data class PaintSplatter(val x: Float, val y: Float, val color: Int, val radius: Float = 35f)

class Enemy(
    val name: String,
    var x: Float,
    var y: Float,
    val color: Int,
    var speed: Float = 3.5f,
    var health: Int = 2
) {
    val radius = 35f
    var isDead = false
    private var lastAttackTime = 0L

    fun update(targetX: Float, targetY: Float, bounds: RectF) {
        if (x < targetX) x += speed
        if (x > targetX) x -= speed
        if (y < targetY) y += speed
        if (y > targetY) y -= speed

        x = x.coerceIn(bounds.left + radius, bounds.right - radius)
        y = y.coerceIn(bounds.top + radius, bounds.bottom - radius)
    }

    fun canAttackPlayer(): Boolean {
        val now = System.currentTimeMillis()
        if (now - lastAttackTime > 1200) {
            lastAttackTime = now
            return true
        }
        return false
    }

    fun draw(canvas: Canvas) {
        val p = Paint()

        p.color = color
        canvas.drawRect(x - 22f, y - 10f, x + 22f, y + 35f, p)

        p.color = Color.parseColor("#e0a96d")
        canvas.drawCircle(x, y - 30f, 22f, p)

        if (name == "Trump") {
            p.color = Color.RED
            canvas.drawRect(x - 24f, y - 50f, x + 24f, y - 35f, p)
        }

        p.color = Color.WHITE
        p.textSize = 24f
        canvas.drawText(name, x - 30f, y - 55f, p)
    }
}
